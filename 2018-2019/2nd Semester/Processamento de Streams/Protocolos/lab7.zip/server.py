#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 00:51:20 2019

@author: nmp
"""

import socket
import datetime
import time


HOST = "0.0.0.0"
PORT = 7777 

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(5)
f = open("/data/web.log", "r")
lines = f.readlines()
f.close()
while True:
    try:
        conn, addr = s.accept()
        firstTime = -1
        firstWallTime = -1
        for line in lines:
            if line == '' :
                break
            lineTime = datetime.datetime.strptime(line[:23], '%Y-%m-%dT%H:%M:%S.%f')
            if firstTime == -1 :
                firstTime = lineTime
                firstWallTime = datetime.datetime.now()
            diffTime = lineTime - firstTime
            diffMs = diffTime.total_seconds() * 1000 + diffTime.microseconds / 1000
            wallTime = datetime.datetime.now()
            diffWallTime = wallTime - firstWallTime
            diffWallMs = diffWallTime.total_seconds() * 1000 + diffWallTime.microseconds / 1000
            if diffWallMs < diffMs :
                time.sleep( (diffMs - diffWallMs) / 1000)
            conn.sendall( line.encode())
        conn.close()
    except (BrokenPipeError):
        # do nothing
        True
