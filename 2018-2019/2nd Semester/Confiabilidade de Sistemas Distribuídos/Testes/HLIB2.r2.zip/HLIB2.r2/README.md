/* Please keep this library only for research and experimental use
 * in NOVA LINCS Internal Research Activities.
 * for protection of future use for future  publication purposes 
 * and related prototypes and as partial materials tp be protected
 * by patents.
 * Henrique Domingos, 17/Feb/2017
*/

HKIB/MLIB V.1.2r2
rev. 17/Feb/2017, Henrique Domingos

===============================
Notice:
This release dont include applications or complementary MW tools and
runtime environments, as well as, serachable encryption algorithms to
support image-processing operations on multimodal encrypted data,
and applications in the Information Retrieval Research Domain,
according to my recent publications in:
- IEEE Transactions on Cloud Computing Journal (2017)
- DSN 2017 Intl. Conference on  Dependable Systems and Networks 

For thos complementary support, please contact hj@fct.unl.pt.

hj@fct.unl, 17/Feb/2017
===============================

Installation Instructions

This version of the lib only uses (partially) native JCE-based
cryprographic providers, using by default the native providers
already included in the Java SDK framework. If you prefer,
you can simply use the cryptoproviders from BouncyCastle (BC), but
in this case you must install the BC crypto-providers and
iterate in the crypt code if you intend to use and instantiate
the correspondent algorithms.
If this is not the case, you must be able to install the library
using the default implementation.

Here are the steps to use the LIBS and to put ready for use.
This behavior is for use in a Eclipse IDE project.

I - Installation process

step 1) 
   Create a new eclipse Java Project naming it "crypt".
   Recommended use of Java 8 (but it should work with JAVA 7)

step 2)
   Put the sources in the folder "src" to the sources folder of the project

step 3)
   You must refresh the project (File -> Refresh)

step 4)
   You must try to Run trial tests, or use the classes as a Library. 
   In Eclipse you will create your Project aside and include "src" 
   project in your java building path 
   (Propreties -> Java Building Path -> Properties)

step 5)
   There are some initial demos on "how to use" the cryptographic primitives
   available from the library (see hlib/hj/mlib/*)
   These demos are in the hierarchy of sources (see hlib/hj/demos)
   You have equivalent demo-code in the root directory.

step 6)
   Try to write now more demos (ex., in a extended-demos diretory).
   As your first programming examples (demo1, demo2, demo3, ... etc) I
   suggest to write code to combine (or to compose) different methods,
   for example following an onion-based encryption model.
   Another suggestion is to think on cocrete application scenarios where
   you find that a composition of the provided primitives can be offeres
   as an upper-layer API to facilitate the effort of programmers that
   can be involved in developments for such application scenarios.



   


