package csd;

import csd.security.*;
import java.util.*;

public class Tester
{
	public static String toHex( byte[] arr) {
		StringBuffer buf = new StringBuffer();
		for( int i = 0; i < arr.length; i++) {
			if( (arr[i] & 0x80) == 0x80)
				buf.append( Integer.toHexString( i));
			else
				buf.append( "0" + Integer.toHexString( i));
		}
		return buf.toString();
	}

	public static void testSecureRandom() throws Exception {
		System.out.println( "================================================================");
		System.out.println( "=============  GERADOR DE NUMEROS ALEATORIOS  ==================");
		System.out.println( "================================================================");

		// Gera��o de informa��o aleat�ria para construir uma semente
		byte[] seed = new SecureRandom().randomBytes( 16);

		// Verificar que a semente produz a mesma sequ�ncia
		System.out.println( "aleatorio 1 : " + new SecureRandom( seed).randomBytes( 1)[0]);
		System.out.println( "aleatorio 1 : " + new SecureRandom( seed).randomBytes( 1)[0]);
	}

	public static void testDigest( String secret, String clearText) throws Exception {
		System.out.println( "================================================================");
		System.out.println( "==================  FUNCOES DE SINTESE =========================");
		System.out.println( "================================================================");

		byte[] secretArr = secret.getBytes();
		byte[] clearTextArr = clearText.getBytes();

		// Cria object para efectuar digest 
		Digest d1 = Digest.createDigest();
		// adiciona dados 
		d1.update( clearTextArr);
		d1.update( secretArr);
		byte[] d1Arr = d1.getDigest();

		// Comprimento do Digest/Hash
		System.out.println( "Comprimento da sintese (metodo 1) " + d1Arr.length);

		String msg = clearText + secret;
		byte[] msgArr = msg.getBytes();

		// Cria digest usando m�todo alternativo
		byte[] d2Arr = Digest.getDigest( msgArr);
		// Comprimento do Digest/Hash
		System.out.println( "Comprimento da sintese (metodo 2) " + d2Arr.length);

		//Verifica igualdade dos digests
		System.out.println( "Digest igual = " + Arrays.equals( d1Arr, d2Arr));
	}

	public static void testSymCrypto( String secret, String clearText) throws Exception {
		System.out.println( "================================================================");
		System.out.println( "===============  CRIPTOGRAFIA SIMETRICA  =======================");
		System.out.println( "================================================================");

		secret = "1234567890123456";
		byte[] clearTextArr = clearText.getBytes();

		System.out.println( "Texto em claro: (" + clearTextArr.length + " bytes)=" + clearText);

		// Criar a uma chave para criptografia sim�trica a partir de uma string
		SymetricKey key = SymetricKey.createKey( secret);

		// Cifrar o texto
		byte[] cipherText = key.encrypt( clearTextArr);
		System.out.println( "Texto cifrado (" + cipherText.length + " bytes)=" + toHex( cipherText));

		// Exportar a chave original
		byte[] keyArr = key.exportKey();
		// Reconstruir uma chave que havia sido exportada
		SymetricKey key2 = SymetricKey.createKey( keyArr);

		byte[] keyArr2 = key2.exportKey();
		System.out.println( "same key:" + Arrays.equals( keyArr, keyArr2));

		// Decifrar o texto, usando a chave reconstru�da.
		byte[] decClearTextArr = key2.decrypt( cipherText);
		String outputText = new String( decClearTextArr);
		System.out.print( "Texto decifrado:" + outputText);

	}

	public static void testAsymCrypto( String secret, String clearText) throws Exception {
		System.out.println( "================================================================");
		System.out.println( "===============  CRIPTOGRAFIA ASSIMETRICA  =====================");
		System.out.println( "================================================================");

		byte[] clearTextArr = clearText.getBytes();
		System.out.println( "Texto em claro: (" + clearTextArr.length + " bytes)=" + clearText);

		System.out.println( "Gerando par de chaves publica/privada. (Pode demorar muito tempo...)");
		KeyPair pair = KeyPair.createKeyPair();
		System.out.println( "Terminado.");

		// Obter as chaves individuais
		PublicKey pub = pair.getPublic();
		PrivateKey prv = pair.getPrivate();

		byte[] pubKeyArr = pub.exportKey();
		byte[] prvKeyArr = prv.exportKey();
		// Reconstruir as chaves depois de exportadas 
		PublicKey pub2 = PublicKey.createKey( pubKeyArr);
		PrivateKey prv2 = PrivateKey.createKey( prvKeyArr);

		// Cifrar o texto com a chave privada
		byte[] cipherText = prv.encrypt( clearTextArr);
		// Decifrar com a chave p�blica original
		byte[] decClearTextArr = pub.decrypt( cipherText);
		String outputText = new String( decClearTextArr);
		System.out.println( "texto cifrado chave original (" + cipherText.length + " bytes)=" + toHex( cipherText));
		System.out.println( "texto cifrado chave original+decifrado chave original: " + outputText);

		// Decifrar com a chave p�blica reconstru�da
		decClearTextArr = pub2.decrypt( cipherText);
		outputText = new String( decClearTextArr);
		System.out.println( "texto cifrado chave original+decifrado chave copia: " + outputText);

		// Cifrar o texto com a chave p�blica
		cipherText = pub.encrypt( clearTextArr);
		// Decifrar com a chave privada original
		decClearTextArr = prv.decrypt( cipherText);
		outputText = new String( decClearTextArr);
		System.out.println( "texto cifrado chave copia+decifrado chave original: " + outputText);
		// Decifrar com a chave privada reconstru�da
		decClearTextArr = prv2.decrypt( cipherText);
		outputText = new String( decClearTextArr);
		System.out.println( "texto cifrado chave copia+decifrado chave copia: " + outputText);
	}

	public static void main( String[] args) throws Exception {
		String secret = "chave_secreta";
		String clearText = "0123456";

		if( args.length >= 1)
			clearText = args[0];
		if( args.length >= 2)
			secret = args[1];

		testSecureRandom();

		testDigest( secret, clearText);

		testSymCrypto( secret, clearText);

		testAsymCrypto( secret, clearText);

	}
}
