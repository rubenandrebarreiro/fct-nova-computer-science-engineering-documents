echo "Run 'mvn package' first to create jar file"
echo "Replace $(pwd) by the current directory if not running"
docker run -it -v $(pwd):/home sconecuratedimages/apps:8-jdk-alpine java -cp /home/target/lab09-scone-0.1-jar-with-dependencies.jar csd.lab09.HelloWorld
