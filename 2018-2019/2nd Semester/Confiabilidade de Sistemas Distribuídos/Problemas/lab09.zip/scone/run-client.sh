echo "Run 'mvn package' first to create jar file"
echo "Replace $(pwd) by the current directory if not running"
docker network create csd-net
docker run -it --network=csd-net -v $(pwd):/home sconecuratedimages/apps:8-jdk-alpine java -cp /home/target/lab09-scone-0.1-jar-with-dependencies.jar csd.lab09.TimeRestServer http://server:9999/rest/time