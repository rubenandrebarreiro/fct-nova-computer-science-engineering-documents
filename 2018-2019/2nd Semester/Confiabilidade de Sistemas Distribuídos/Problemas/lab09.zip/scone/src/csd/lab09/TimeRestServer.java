package csd.lab09;

import java.net.InetAddress;
import java.net.URI;
import org.glassfish.jersey.jdkhttp.JdkHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

public class TimeRestServer
{
	static {
		System.setProperty("java.net.preferIPv4Stack", "true");
	}

	public static final int PORT = 9999;
	public static final String SERVICE = "Microgram-MediaStorage";
	public static String SERVER_BASE_URI = "http://%s:%s/rest";

	public static void main(String[] args) throws Exception {

		ResourceConfig config = new ResourceConfig();
		config.register(new TimeResource());

		JdkHttpServerFactory.createHttpServer(URI.create("http://0.0.0.0:" + PORT + "/rest"), config);
		System.out.println("Time REST server started at server : " + InetAddress. getLocalHost().getHostName());
	}
}
