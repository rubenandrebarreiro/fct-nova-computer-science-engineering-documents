package csd.lab09;

import java.io.IOException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.client.ClientConfig;

public class TimeRestClient
{
	public static void main(String[] args) throws IOException {

		String serverUrl = args.length > 0 ? args[0] : "http://localhost:9999/rest";

		ClientConfig config = new ClientConfig();
		Client client = ClientBuilder.newClient(config);

		WebTarget target = client.target(serverUrl).path(TimeResource.PATH);

		Response r = target.request().accept(MediaType.APPLICATION_JSON).get();

		if (r.getStatus() == Status.OK.getStatusCode() && r.hasEntity())
			System.out.println("Response: " + r.readEntity(String.class));
		else
			System.out.println("Status: " + r.getStatus());

	}

}
