package csd.lab09;

public class HelloWorldThreads
{
	public static void main( String[] args) {
		new Thread( new Runnable() {
			@Override
			public void run() {
				System.out.println( "Hello from first thread !!");			
			}
		}). start();
		new Thread( new Runnable() {
			@Override
			public void run() {
				System.out.println( "Hello from second thread !!");			
			}
		}). start();
	}
}
