package csd.lab09;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;


@Path(TimeResource.PATH)
public class TimeResource
{
	public static final String PATH="/time";

	DateFormat fmt;
	
		public TimeResource() {
			fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		}
		
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public String getTime(){
			System.out.println("Received request");
//			System.out.println("Received request from : " + request.getRemoteAddr());
			return fmt.format( new Date());
		}
}
