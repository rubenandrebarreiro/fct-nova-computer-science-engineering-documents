#!/bin/sh -e
# ESET Remote Administrator (OnlineInstallerScript)
# Copyright (c) 1992-2016 ESET, spol. s r.o. All Rights Reserved

cleanup_file="$(mktemp -q)"
finalize()
{
  set +e
  if test -f "$cleanup_file"
  then
    while read f
    do
      unlink "$f"
    done < "$cleanup_file"
    unlink "$cleanup_file"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="era-app.ci.fct.unl.pt"
eraa_server_port="2222"
eraa_peer_cert_b64="MIIJhQIBAzCCCU8GCSqGSIb3DQEHAaCCCUAEggk8MIIJODCCA+8GCSqGSIb3DQEHBqCCA+AwggPcAgEAMIID1QYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIfXlFXnEUzecCAggAgIIDqNeSvj0yD6x00lmee13EvJodi+/UeYqg3DKeQfaD0BbgiZq9c7cK7F5ap82iuX/5a6PVBnxA9ywPbPQ6A0ZLRSfevNL9kVG7aUHO3WQD3pJ88Gm3V1QwTySso+0tdRSnqksOBYtPgVlfAk5ZEp1EHwnldMnmH7B3Pm8xadIlMADZMruBipBDmin1QlXQp2UF/LralcxQuZPPJwPXqbkyphZxQkW5QAPMtfl6Ei1SgZYOKA4kr6f7pXtBRAaIPNUgbSMf687+yLnTwSdhmtY2mGa8GuLjtPqLZOg4ZtpXjKfWO/BS9GUDqEmQ8lVP5RH+dxPWAKjGNH7/quNfgSnoghvdWtPSmOLft0ta1P8vDxXfskruUEcEuQ2JUbtZMdWPhg4G75kz4pkL7OrXK6yx4Tj7whzXcU7g5vFyJX03F5fJKy4oZzvpPo1byk4q0xjJoDMkBsAtRxV7m/ZyVxVkZExb59txkggxKyfJO2zFrYUkuC5PdaeniB6K/SdoWv+YmOwqkv0RRuSbL8HZkz50Owx02phjXZOhdQhuY7L5cGhE7SgFSaC9t2Qzs+PFFJncSaApZFHCvXriz9p/4j7i2/AEbOBKxA/PBRd2q0Vb9dMjnOUP8v+jTThIMMCjbIc7KdWcODkYvAg2cRw8JDdzSpdW3udVNLLDnXEG1r6HBiZFYXGVICIJTOa6b45EAhV5ro+XaJjKbzXqhS6QJEmUDWG0FxxAqDRz9/1RdhUXQIjnBNTBfGfDjCZDoGK5KlgLTHUhj38pgeqd2SjLt5YtNifcBH6VTk1N4uFQJ0gyXh7CJsUcluZUk4mX8AVn+TThZgKVXYL2nyzRxbzdurqHPGJHa0QQEKtoIAVpyAxIt6JznBFRElzZ+N4L4CHH0jpo7V6wRWWktOTA0DJYRVOdiqQmWuatSg2xFPbZ+uSxzudgM3ysrgs4MNkFPIJcJbITB3HudeZVnmuEihTyXf0sNvqvgXrKiujKKCCNZ2HCiRai94EdG0a+bSMSYD7rmDJHaePv0P+xxmdmMmlRIHPhRHTKuceB4p7ypw4CH+lrkiRwACoDV9Qekv8hRIvKbK3E6w9GPe1FF1YqB1aViZDdpfIBwaBmH3xN0X0oKpA5pvKOiYFBS50UHw4nPFdbIhocpJy+WBJ/Otgg3NPcgOpRdySdkHSQA7LREsQNoLw5PKsXlyH44KLHi5gkOWPNT4ZsiaZ7zDMD8JLHNUCWzxF6s30u0cD/wK3l+zCCBUEGCSqGSIb3DQEHAaCCBTIEggUuMIIFKjCCBSYGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBAzAOBAivZ2WvDRN+IwICCAAEggTIeArU7tqYnMLFd6D+K9TpAI231n9N+cuYgGpUBwJvJRqkNP0BHw+ZuaxlPlTgrRrsdVvdF9yjKla80y5ibEbdD6r0FyQ44fC61PEWD6Pm53wWktcLce4Vg0KzQxC+ofG9dXg+DDcFj7arb29yaOYnB1YKgqxO03BGT+H7Y7CaoKNdAFfQrCTYKztzLqB6J4LUn2R30Pb909zxI3utOmYkfYe8Whl93hM0SJhCgiCa2YD4AUyPmNIq0aOdXoIXpjxjZE0+uKp0Rq8BEYqNrkxJiO/GTH4tzUicrO1OkK5nuwR5q5va7SfBFm5pAqS3GzxoKBuP3Qtl0YgEXh2Z9FoXblAwU8vz5L8WyuUBbxtR+H6PtwDJJCx7I9tdEekaljr0IF/2Q97rsPWK+FbM8nC5/1KHardG8OC/BuzxFkqlNHbSdeMePFNelVhZvXNe1NP8vF+OM2E4saS+0Ntp1v9h2OnswKMaT31JpTnronF+jOwWD6V8Ggp2HZaJ3rznzDj8Wtj0UHZCP+LI3amIPKqDHqrM/jclp+oGDfb3tJG0dBnjBKLIHnusR2L3MJ8KCshh5YNI1GZIYSUKSgoDCaALSvsHlNxnx9zgHbfUizFBdeHnNnvuu8dOuDeh9ysxlr3t0T21e4EIb0g1XTB6sUjsE7TvBowscwpXMiIdJ/SYZRURsICaNGnxdyGQ8RhKLTgytwFsdIWvWl+L4+a3N2091vA6Vo4z2G+nO+rNRBnodS+trhlw1UTZJOyQuslFZs26RNgSr+7blsXkaOB8SUc4j+X1Idsp7Z7KH3QGRQYTy1yqhi4DykjxpX3CVhYYu44VQwwSzXvtxdS6Ilipu9XnkPS6P4kgvZCWAlv1RhzwiPeNoxzzRBd9DlXRS3BjZkmtsCrB9k+o/sdM/YpUxY6eL6dlXugmLPMJfzF6swQq5869VpYIAbfSZi3M8qlB7abZPw6vOI0H43SMc5N7KJnYCLOmSD0EG6U6UVl4NvC4rIXQ2lWspBbCBcW7xuUPTnCavSAdUdPyk9eMjJ7Lw767DAn+d4c35PTOzeKqASe5IhDUL+4YpfbiemvlL50d7qn2RKodOIMV1DBYuAM4/UM2o6bVdXKV010Uxa99VHfaTTMb1leJ+BjiHURIiqbKeQfzOE1OiGVWO3g3D8Q55FgsVdGXVA2U7SSn8qq54J/G5dedw0IZDTWVrdHEv4h73v3jUrTBhRduIGoJrkzmtKH2+YHg0NdOdkoWuoH2aj0dEXgotb6t8LkxuQSI4/U1fHzhio/KIlkF5nAInsNwTFUTM9eC50fTaC/bxNLcS96fI0BeTHAWezAnD4zCY4YIFk8vYxLR24XhexXIAvVQQwDzPd4aCLMzyT3yPctFnrIrFybuY8GvYSBNpF+pkqUD6SihDvy34ZQLPFFIr2pXIngyurNFhML6671EfFgHxXq+4daSoUW4aTjZf6ks2idHCpHqFeDMM0PYoq9MT/367+IbnFS8/lsmENOuiFpHOUTODQAEpt9TvYkG6zML7dXJ7ObHZYdm+WlN2tp+cDa7yV38kA8fVResE9Ev4qVN3OCtdA3wQ12glsi3SfPNl3KO+0vjvDrk3zDC7WM0xUxsi5Uc92T7wJmda39IMSUwIwYJKoZIhvcNAQkVMRYEFDqgOUuAmwep4ZfVhF4rC/SXG6BrMC0wITAJBgUrDgMCGgUABBRQMBaKmJxFVyyAZZddGOUakpsh8AQICHFSoGL362Y="
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIDuzCCAqOgAwIBAgIQGRwKiofW27tMbGNM4oPl8jANBgkqhkiG9w0BAQUFADB2MScwJQYDVQQDEx5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxDDAKBgNVBAsTA0ZDVDEMMAoGA1UEChMDVU5MMQ8wDQYDVQQHEwZMSVNCT04xETAPBgNVBAgTCFBPUlRVR0FMMQswCQYDVQQGEwJQVDAeFw0xNjA2MjEwMDAwMDBaFw0yNjA2MjMwMDAwMDBaMHYxJzAlBgNVBAMTHlNlcnZlciBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEMMAoGA1UECxMDRkNUMQwwCgYDVQQKEwNVTkwxDzANBgNVBAcTBkxJU0JPTjERMA8GA1UECBMIUE9SVFVHQUwxCzAJBgNVBAYTAlBUMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtVx4YEY+aTnnZm6m66FQi9G/S4qMS6GMYC1wtdZtvMhlwSHu1S1v+JuHrAPW9Pl6n8s0vKz0dcnSQiAD+jqUrJgjv746jxaI19U6V5xWVZQe+xrrK3h54KErGNnb1o3eoJxVtR68lteksIIKcaFEMCRqnHr0h/Gb0Bh9/CzlMguRFPpBVGLvgcd8Tq7+Nl0dfH5CrUpIgvMphepJssuHkNrZoq7GSHMqEB83lGYZwPRXbTkh4Sj0jIRiWAdubG5QvLPylQ6LGEuXQ81LK3AU0lAWGWV3F6iW55KJMwGptOEaoEb6SVsS7FIDfJdk25QDl5lonBe9DQ60WpfSqfdbiQIDAQABo0UwQzAOBgNVHQ8BAf8EBAMCAQYwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUFH2PoQkNJMMiBLD91wrCQFhroxcwDQYJKoZIhvcNAQEFBQADggEBAJV41qw8Gdx0KeiqIHWzmWGvz4Vsc49zWu6Sk47w4TIOzCKm2QrY1SyJBOC/NzQGvqwBaq7Rd4yjP3C8tVPZhvBiyv33hSxOF5vhWzh+GwWjfHTZ0zKQqd412w/BaB4RT17YV7IY9jVHQshnz7IcYFyaNlZcMFnJRVMBOs9OldxEQ/XLQEPnS8ZkM52jtNZi7KJ0UTo9F9fKJANaWKr8qnRSSFF4y3d4FfTV+yjfgU7w1p64FyyLVvWe7hl6OWnnV/KwpvxtPfWZMX/llmGS/dyZR2nK1u0HPEj4G+eAvGvx/6gqxV9J3nTi+O951KGUJIRq/pKrh8/E6OMZL8ILEyI="
eraa_product_uuid=""
eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v6/6.5.417.0/agent-linux-i386.sh"
eraa_installer_checksum="ff606fd0e4fb5f5de88bebf722667f85a0516ff5"
eraa_initial_sg_token="MDAwMDAwMDAtMDAwMC0wMDAwLTcwMDEtMDAwMDAwMDAwMDAyNG/7PtgUSpOxT82ZXhr+UOkJSTILPEGGjFXnxdAS80G8FdoU43/jBQZ5q+eCpKesRU/KEQ=="

arch=$(uname -m)
if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 >> /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v6/6.5.417.0/agent-linux-x86_64.sh"
    eraa_installer_checksum="e9b2f43f0fad23100eb0b5ea5c3ba6e14240aaae"
fi

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture. Sorry :/"
  exit 1
fi

local_cert_path="$(mktemp -q -u)"
echo $eraa_peer_cert_b64 | base64 -d > "$local_cert_path" && echo "$local_cert_path" >> "$cleanup_file"

if test -n "$eraa_ca_cert_b64"
then
  local_ca_path="$(mktemp -q -u)"
  echo $eraa_ca_cert_b64 | base64 -d > "$local_ca_path" && echo "$local_ca_path" >> "$cleanup_file"
fi

local_installer="$(mktemp -q -u)"

eraa_http_proxy_value="http://193.136.126.84:3128"
if test -n "$eraa_http_proxy_value"
then
  export use_proxy=yes
  export http_proxy="$eraa_http_proxy_value"
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || wget --connect-timeout 300 --no-proxy --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
else
  (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
fi

echo -n "Checking integrity of installer script " && echo "$eraa_installer_checksum  $local_installer" | sha1sum -c

chmod +x "$local_installer"

local_migration_list="$(mktemp -q -u)"
tee "$local_migration_list" 2>&1 > /dev/null << __LOCAL_MIGRATION_LIST__

__LOCAL_MIGRATION_LIST__
test $? = 0 && echo "$local_migration_list" >> "$cleanup_file"

for dir in /sys/class/net/*/
do
    if test -f "$dir/address"
    then
        grep -E '00:00:00:00:00:00' "$dir/address" > /dev/null || macs="$macs $(sed 's/\://g' "$dir/address" | awk '{print toupper($0)}')"
    fi
done

while read line
do
    if test -n "$macs" -a -n "$line"
    then
        mac=$(echo $line | awk '{print $1}')
        uuid=$(echo $line | awk '{print $2}')
        lsid=$(echo $line | awk '{print $3}')
        if $(echo "$macs" | grep "$mac" > /dev/null)
        then
            if test -n "$mac" -a -n "$uuid" -a -n "$lsid"
            then
                additional_params="--product-guid $uuid --log-sequence-id $lsid"
                break
            fi
        fi
    fi
done < "$local_migration_list"

command -v sudo >> /dev/null && usesudo="sudo -E" || usesudo=""

export _ERAAGENT_PEER_CERT_PASSWORD="$eraa_peer_cert_pwd"

echo
echo Running installer script $local_installer
echo

$usesudo "$local_installer"\
   --skip-license \
   --hostname "$eraa_server_hostname"\
   --port "$eraa_server_port"\
   --cert-path "$local_cert_path"\
   --cert-password "env:_ERAAGENT_PEER_CERT_PASSWORD"\
   --cert-password-is-base64\
   --initial-static-group "$eraa_initial_sg_token"\
   $(test -n "$local_ca_path" && echo --cert-auth-path "$local_ca_path")\
   $(test -n "$eraa_product_uuid" && echo --product-guid "$eraa_product_uuid")\
   $additional_params
